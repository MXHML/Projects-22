document.getElementById('gslogo');

let nav = document.getElementById("navO");

navO.addEventListener('click',openNav());

function openNav() {
    navO.style.width = "100%";
  }
  
  function closeNav() {
    navO.style.width = "0%";
  }